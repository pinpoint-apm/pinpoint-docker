package com.navercorp.pinpoint.web.alarm;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;

import com.navercorp.pinpoint.web.alarm.checker.AlarmChecker;
import com.navercorp.pinpoint.web.service.UserGroupService;

public class AlarmMessageSenderImple implements AlarmMessageSender {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    
    private MailSender mailSender;

    public void setMailSender(MailSender mailSender) {
		this.mailSender = mailSender;
	}

	@Autowired
    private UserGroupService userGroupService;
    
    @Override
    public void sendSms(AlarmChecker checker, int sequenceCount) {
        List<String> receivers = userGroupService.selectPhoneNumberOfMember(checker.getuserGroupId());

        if (receivers.size() == 0) {
            return;
        }

        for (String message : checker.getSmsMessage()) {
            logger.info("send SMS : {}", message);

            // TODO Implement logic for sending SMS
        }
    }

    @Override
    public void sendEmail(AlarmChecker checker, int sequenceCount) {
        List<String> receivers = userGroupService.selectEmailOfMember(checker.getuserGroupId());

        if (receivers.size() == 0) {
            return;
        }

        logger.info("send email : {}", checker.getEmailMessage());
        try{
	        SimpleMailMessage message = new SimpleMailMessage(); 
	        message.setTo(receivers.toArray(new String [receivers.size()])); 
	        message.setSubject(String.format("[PINPOINT Alarm - %s]", checker.getRule().getApplicationId())); 
	        message.setText(String.format("%s\n\n%s", checker.getEmailMessage(), checker.getRule().getNotes()));
	        mailSender.send(message);
        }catch(Exception e){
        	logger.error("send email error", e);
        }
    }
}
